num_list = [10, 20, 30, 40, 50, 60, 70, 80, 90]
for i in num_list:
    if i ==60:
        continue
    if i == 70:
        break
    print(i)