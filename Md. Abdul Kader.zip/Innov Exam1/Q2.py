base_salary = int(input("What is your salary? "))
bonus = base_salary * 0.1
print("Your bonus is:", bonus)